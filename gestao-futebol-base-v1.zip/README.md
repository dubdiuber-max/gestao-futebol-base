# Gestão Futebol de Base

Aplicativo web responsivo para gestão de uma escolinha de futebol. Stack: React + Vite, Firebase Authentication, Cloud Firestore e Vercel.

## O que já funciona nesta versão
- Painel com indicadores de atletas, recebimentos, pendências e campeonatos.
- Cadastro e listagem de atletas, categoria, posição e responsável.
- Cadastro de mensalidades e registro manual de pagamento.
- Cadastro de campeonatos e seleção de atletas inscritos por categoria.
- Criação de convocações por partida, com opção de marcar como publicada.
- Modo demonstração local (sem Firebase), com dados guardados no navegador.
- Interface responsiva para celular e computador.

## Pré-requisitos
- Node.js 20 ou superior
- Conta Firebase
- Conta GitHub e Vercel para publicação

## Rodar localmente
```bash
npm install
cp .env.example .env.local
npm run dev
```
Sem preencher as variáveis Firebase, o aplicativo abre em modo demonstração. Os registros ficam no `localStorage` do navegador e não são compartilhados entre dispositivos.

## Configurar Firebase
1. Crie um projeto em https://console.firebase.google.com/.
2. Adicione um aplicativo Web e copie as configurações para `.env.local`.
3. Ative Authentication > Sign-in method > Email/Password.
4. Crie o banco Firestore em modo produção.
5. Publique as regras do arquivo `firestore.rules`.
6. Crie o primeiro usuário em Authentication > Users.
7. No Firestore, crie manualmente `userProfiles/{UID_DO_USUARIO}` com o campo `role` (string) igual a `admin`.
8. Entre no app com o e-mail e senha criados.

Variáveis necessárias:
- `VITE_FIREBASE_API_KEY`
- `VITE_FIREBASE_AUTH_DOMAIN`
- `VITE_FIREBASE_PROJECT_ID`
- `VITE_FIREBASE_STORAGE_BUCKET`
- `VITE_FIREBASE_MESSAGING_SENDER_ID`
- `VITE_FIREBASE_APP_ID`

Opcional para mostrar/copiar a chave PIX:
- `VITE_PIX_KEY`
- `VITE_PIX_RECEIVER`

## Publicar no GitHub e Vercel
1. Crie um repositório GitHub vazio chamado `gestao-futebol-base`.
2. Envie todos os arquivos deste projeto para a raiz do repositório.
3. Na Vercel, importe o repositório GitHub.
4. Framework preset: Vite. Build command: `npm run build`. Output directory: `dist`.
5. Cadastre na Vercel as mesmas variáveis `VITE_FIREBASE_*` e, se desejar, `VITE_PIX_KEY` e `VITE_PIX_RECEIVER`.
6. Faça o deploy. A cada atualização enviada ao GitHub, a Vercel poderá publicar uma nova versão.

## Importante sobre PIX
Esta versão registra e controla mensalidades, mostra a chave PIX configurada e permite ao administrador marcar o pagamento como recebido. Ela **não gera cobrança dinâmica, QR Code de cobrança nem confirma pagamentos automaticamente**. Para isso, é necessária integração com um provedor de pagamentos (por exemplo, Asaas), credenciais privadas guardadas no backend e webhook validado. Nunca coloque token secreto do provedor em variáveis `VITE_*`, pois elas ficam acessíveis no navegador.

## Limitações e próxima etapa
- A área de responsável/pais ainda não está habilitada nesta primeira entrega.
- As convocações marcadas como publicadas ficam registradas no painel; envio de notificações/WhatsApp será etapa posterior.
- Regras atuais do Firestore permitem acesso apenas a usuários cujo documento `userProfiles/{uid}` tenha `role: "admin"`. O portal dos pais exige regras por responsável e vínculo seguro atleta-responsável antes de ser liberado.
- Antes de usar com dados reais de menores, configure controles de acesso, política de privacidade, consentimento dos responsáveis e rotina de backup.
