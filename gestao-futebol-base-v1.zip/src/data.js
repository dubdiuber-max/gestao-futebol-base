import { collection, addDoc, deleteDoc, doc, getDocs, updateDoc, query, orderBy } from 'firebase/firestore';
import { db, firebaseReady } from './firebase';

const seed = {
  athletes: [
    {id:'a1',name:'Davi Rodrigues',birth:'2014-09-21',category:'Sub-12',position:'Zagueiro',guardian:'Responsável de exemplo',phone:'(19) 99999-0000',active:true},
    {id:'a2',name:'Lucas Martins',birth:'2014-03-12',category:'Sub-12',position:'Atacante',guardian:'Mariana Martins',phone:'(19) 99999-0001',active:true},
    {id:'a3',name:'Pedro Henrique',birth:'2015-01-08',category:'Sub-11',position:'Goleiro',guardian:'Carlos Henrique',phone:'(19) 99999-0002',active:true},
  ],
  bills: [
    {id:'b1',athleteId:'a1',athleteName:'Davi Rodrigues',month:'Novembro/2026',amount:120,due:'2026-11-10',status:'Pendente',method:'PIX'},
    {id:'b2',athleteId:'a2',athleteName:'Lucas Martins',month:'Novembro/2026',amount:120,due:'2026-11-10',status:'Pago',method:'PIX'},
    {id:'b3',athleteId:'a3',athleteName:'Pedro Henrique',month:'Novembro/2026',amount:100,due:'2026-11-10',status:'Pendente',method:'PIX'},
  ],
  competitions: [
    {id:'c1',name:'União Cup 2027',category:'Sub-12',date:'2027-02-15',location:'A definir',notes:'Competição de exemplo',athleteIds:['a1','a2']},
  ],
  callups: [
    {id:'k1',competitionId:'c1',competitionName:'União Cup 2027',match:'Jogo de abertura',date:'2027-02-15',category:'Sub-12',athleteIds:['a1'],published:true},
  ],
};
const key = 'gfb_demo_v1';
function demoRead() { try { return JSON.parse(localStorage.getItem(key)) || seed; } catch { return seed; } }
function demoWrite(data) { localStorage.setItem(key, JSON.stringify(data)); }
export async function listItems(type) {
  if (!firebaseReady) return demoRead()[type] || [];
  const snap = await getDocs(query(collection(db,type), orderBy('createdAt','desc')));
  return snap.docs.map(d=>({id:d.id,...d.data()}));
}
export async function saveItem(type,item) {
  if (!firebaseReady) { const data=demoRead(); const list=data[type]||[]; const idx=list.findIndex(x=>x.id===item.id); if(idx>=0) list[idx]=item; else list.unshift({...item,id:item.id||crypto.randomUUID()}); data[type]=list; demoWrite(data); return item; }
  const {id,...payload}=item;
  if(id) { await updateDoc(doc(db,type,id),payload); return item; }
  const ref=await addDoc(collection(db,type),{...payload,createdAt:Date.now()}); return {id:ref.id,...payload};
}
export async function removeItem(type,id) {
  if (!firebaseReady) { const data=demoRead(); data[type]=(data[type]||[]).filter(x=>x.id!==id); demoWrite(data); return; }
  await deleteDoc(doc(db,type,id));
}
export async function markBillPaid(id) {
  const bills=await listItems('bills'); const bill=bills.find(b=>b.id===id); if(bill) await saveItem('bills',{...bill,status:'Pago',paidAt:new Date().toISOString()});
}
